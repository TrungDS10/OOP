// import javax.swing.JOptionPane;
// public class Quest1 {
//     public static void main(String[] args) throws Exception {
//         String name;
//         name = JOptionPane.showInputDialog("What is your name?");
//         JOptionPane.showMessageDialog(null, "Welcome " + name + " to Java Programming!");
//     }
// }
